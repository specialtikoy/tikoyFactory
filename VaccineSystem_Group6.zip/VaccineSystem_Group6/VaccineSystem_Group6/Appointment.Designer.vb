﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAppointment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAppointment))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtEnterAccountId = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboDose = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.cboTimeSlot = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.dtpAppointmentDate = New System.Windows.Forms.DateTimePicker()
        Me.cboSite = New System.Windows.Forms.ComboBox()
        Me.cboPriority = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.cboVaccine = New System.Windows.Forms.ComboBox()
        Me.btnBook = New System.Windows.Forms.Button()
        Me.tmrAppointment = New System.Windows.Forms.Timer(Me.components)
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.lblPlease = New System.Windows.Forms.Label()
        Me.lblGRP6 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.txtEnterAccountId)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.cboDose)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.cboTimeSlot)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.dtpAppointmentDate)
        Me.GroupBox2.Controls.Add(Me.cboSite)
        Me.GroupBox2.Controls.Add(Me.cboPriority)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.cboVaccine)
        Me.GroupBox2.Font = New System.Drawing.Font("Raleway", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(54, 56)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(841, 386)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "BOOK AN APPOINTMENT"
        '
        'txtEnterAccountId
        '
        Me.txtEnterAccountId.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEnterAccountId.Location = New System.Drawing.Point(185, 75)
        Me.txtEnterAccountId.Name = "txtEnterAccountId"
        Me.txtEnterAccountId.Size = New System.Drawing.Size(221, 31)
        Me.txtEnterAccountId.TabIndex = 73
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(52, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(127, 24)
        Me.Label2.TabIndex = 72
        Me.Label2.Text = "* Account ID:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(704, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 24)
        Me.Label4.TabIndex = 71
        Me.Label4.Text = """ * """
        '
        'cboDose
        '
        Me.cboDose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDose.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDose.FormattingEnabled = True
        Me.cboDose.Items.AddRange(New Object() {"1st Dose", "2nd Dose"})
        Me.cboDose.Location = New System.Drawing.Point(441, 322)
        Me.cboDose.Name = "cboDose"
        Me.cboDose.Size = New System.Drawing.Size(350, 32)
        Me.cboDose.TabIndex = 69
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Raleway", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(588, 35)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(236, 16)
        Me.Label11.TabIndex = 70
        Me.Label11.Text = "Note: Fields with          are required"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(437, 286)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 24)
        Me.Label9.TabIndex = 68
        Me.Label9.Text = "* Dose:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(52, 286)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(111, 24)
        Me.Label19.TabIndex = 41
        Me.Label19.Text = "* Time Slot:"
        '
        'cboTimeSlot
        '
        Me.cboTimeSlot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTimeSlot.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboTimeSlot.FormattingEnabled = True
        Me.cboTimeSlot.Items.AddRange(New Object() {"Morning - (8:00 AM -12:00 PM)", "Afternoon - (1:00 PM - 3:00 PM)"})
        Me.cboTimeSlot.Location = New System.Drawing.Point(56, 322)
        Me.cboTimeSlot.Name = "cboTimeSlot"
        Me.cboTimeSlot.Size = New System.Drawing.Size(350, 32)
        Me.cboTimeSlot.TabIndex = 40
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(52, 206)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 24)
        Me.Label18.TabIndex = 39
        Me.Label18.Text = "* Date:"
        '
        'dtpAppointmentDate
        '
        Me.dtpAppointmentDate.CustomFormat = "dd/MM/yyyy"
        Me.dtpAppointmentDate.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpAppointmentDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpAppointmentDate.Location = New System.Drawing.Point(56, 240)
        Me.dtpAppointmentDate.MaxDate = New Date(2030, 12, 7, 0, 0, 0, 0)
        Me.dtpAppointmentDate.Name = "dtpAppointmentDate"
        Me.dtpAppointmentDate.Size = New System.Drawing.Size(350, 31)
        Me.dtpAppointmentDate.TabIndex = 31
        Me.dtpAppointmentDate.Value = New Date(2022, 5, 6, 0, 0, 0, 0)
        '
        'cboSite
        '
        Me.cboSite.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSite.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSite.FormattingEnabled = True
        Me.cboSite.Items.AddRange(New Object() {"SM AURA Premier - Samsung Hall", "Sta. Ana - Barangay Hall", "B7 Bonifacio High Street - VaccHub"})
        Me.cboSite.Location = New System.Drawing.Point(441, 242)
        Me.cboSite.Name = "cboSite"
        Me.cboSite.Size = New System.Drawing.Size(350, 32)
        Me.cboSite.TabIndex = 38
        '
        'cboPriority
        '
        Me.cboPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPriority.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPriority.FormattingEnabled = True
        Me.cboPriority.Items.AddRange(New Object() {"A1 - Frontliners in Health Services", "A2 - Senior Citizens", "A3 - With Comorbidity", "A4 - Uniformed Personnel", "A5 - Indigent Population", "B1 - Teachers, Social Workers", "B2 - Other Government Workers", "B3 - Other Essential Workers", "B4 - Socio-demographic Groups", "B5 - Overseas FIlipino Workers", "B6 - Other Remaining Workforce", "C1 - Excluded in above groups"})
        Me.cboPriority.Location = New System.Drawing.Point(56, 162)
        Me.cboPriority.Name = "cboPriority"
        Me.cboPriority.Size = New System.Drawing.Size(350, 32)
        Me.cboPriority.TabIndex = 36
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(437, 126)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(158, 24)
        Me.Label15.TabIndex = 32
        Me.Label15.Text = "* Vaccine Brand:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(437, 206)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(172, 24)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "* Vaccination Site:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(52, 126)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(145, 24)
        Me.Label16.TabIndex = 34
        Me.Label16.Text = "* Priority Level:"
        '
        'cboVaccine
        '
        Me.cboVaccine.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboVaccine.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboVaccine.FormattingEnabled = True
        Me.cboVaccine.Items.AddRange(New Object() {"Pfizer", "Moderna", "AstraZeneca", "SinoVac", "Sputnik V", "Johnson & Johnson"})
        Me.cboVaccine.Location = New System.Drawing.Point(441, 162)
        Me.cboVaccine.Name = "cboVaccine"
        Me.cboVaccine.Size = New System.Drawing.Size(350, 32)
        Me.cboVaccine.TabIndex = 35
        '
        'btnBook
        '
        Me.btnBook.BackColor = System.Drawing.Color.White
        Me.btnBook.Enabled = False
        Me.btnBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBook.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBook.ForeColor = System.Drawing.Color.Black
        Me.btnBook.Location = New System.Drawing.Point(683, 463)
        Me.btnBook.Name = "btnBook"
        Me.btnBook.Size = New System.Drawing.Size(212, 65)
        Me.btnBook.TabIndex = 34
        Me.btnBook.Text = "BOOK"
        Me.btnBook.UseVisualStyleBackColor = False
        '
        'tmrAppointment
        '
        Me.tmrAppointment.Enabled = True
        Me.tmrAppointment.Interval = 1000
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTime.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.White
        Me.lblDateTime.Location = New System.Drawing.Point(790, 9)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(148, 18)
        Me.lblDateTime.TabIndex = 43
        Me.lblDateTime.Text = "                                   "
        '
        'lblPlease
        '
        Me.lblPlease.AutoSize = True
        Me.lblPlease.BackColor = System.Drawing.Color.Transparent
        Me.lblPlease.Font = New System.Drawing.Font("Raleway", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlease.ForeColor = System.Drawing.Color.White
        Me.lblPlease.Location = New System.Drawing.Point(280, 488)
        Me.lblPlease.Name = "lblPlease"
        Me.lblPlease.Size = New System.Drawing.Size(370, 16)
        Me.lblPlease.TabIndex = 69
        Me.lblPlease.Text = "* Please make sure that all fields are filled-up correctly."
        '
        'lblGRP6
        '
        Me.lblGRP6.AutoSize = True
        Me.lblGRP6.BackColor = System.Drawing.Color.Transparent
        Me.lblGRP6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGRP6.ForeColor = System.Drawing.Color.White
        Me.lblGRP6.Location = New System.Drawing.Point(12, 9)
        Me.lblGRP6.Name = "lblGRP6"
        Me.lblGRP6.Size = New System.Drawing.Size(279, 24)
        Me.lblGRP6.TabIndex = 70
        Me.lblGRP6.Text = "Group 6 : Vaccination System"
        '
        'frmAppointment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(950, 550)
        Me.Controls.Add(Me.lblGRP6)
        Me.Controls.Add(Me.lblDateTime)
        Me.Controls.Add(Me.btnBook)
        Me.Controls.Add(Me.lblPlease)
        Me.Controls.Add(Me.GroupBox2)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmAppointment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label19 As Label
    Friend WithEvents cboTimeSlot As ComboBox
    Friend WithEvents Label18 As Label
    Friend WithEvents dtpAppointmentDate As DateTimePicker
    Friend WithEvents cboSite As ComboBox
    Friend WithEvents Label17 As Label
    Friend WithEvents cboPriority As ComboBox
    Friend WithEvents cboVaccine As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents btnBook As Button
    Friend WithEvents tmrAppointment As Timer
    Friend WithEvents lblDateTime As Label
    Friend WithEvents cboDose As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblPlease As Label
    Friend WithEvents txtEnterAccountId As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lblGRP6 As Label
End Class
