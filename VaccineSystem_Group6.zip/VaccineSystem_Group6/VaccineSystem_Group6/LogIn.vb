﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmLogin

    Dim tableUserName, tablePassWord As String

    Dim role As String

    Dim dateTimeIn As String

    Private Sub tmrLogin_Tick(sender As Object, e As EventArgs) Handles tmrLogin.Tick

        If txtUserName.Text = "" Or txtPass.Text = "" Then
            btnLogin.Enabled = False
        Else
            btnLogin.BackColor = Color.Lime
            btnLogin.Enabled = True
        End If

        If chkShowPass.Checked = True Then
            txtPass.PasswordChar = ""
        Else
            txtPass.PasswordChar = "*"
        End If

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim Profile As frmProfile
        Profile = New frmProfile

        Dim adminPage As frmAdmin
        adminPage = New frmAdmin

        dateTimeIn = DateTime.Now.ToString

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Using searchUsername As SqlCommand = New SqlCommand("SELECT [Username] FROM [dbo].[user_tbl] WHERE [Username] = '" + txtUserName.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + txtPass.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
            Using searchPassword As SqlCommand = New SqlCommand("SELECT [Password] FROM [dbo].[user_tbl] WHERE [Username] = '" + txtUserName.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + txtPass.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)

                connection.Open()

                tableUserName = searchUsername.ExecuteScalar()
                tablePassWord = searchPassword.ExecuteScalar()

                Profile.userNameString = tableUserName
                Profile.passWordString = tablePassWord

                If (txtUserName.Text = tableUserName And txtPass.Text = tablePassWord) And (txtUserName.Text <> "G6_ADMIN" And txtPass.Text <> "G6_ADMIN_P@55") Then

                    role = "User"

                    Dim connection2 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
                    Dim updateUserLogin As SqlCommand = New SqlCommand("INSERT INTO [dbo].[logs_tbl] ([Username],[Role],[DateTimeIn]) VALUES('" + txtUserName.Text + "','" + role + "','" + dateTimeIn + "')", connection)

                    connection2.Open()
                    updateUserLogin.ExecuteNonQuery()
                    connection2.Close()

                    Me.Hide()
                    Profile.Show()

                ElseIf txtUserName.Text = "G6_ADMIN" And txtPass.Text = "G6_ADMIN_P@55" Then

                    role = "System Admin"

                    adminPage.roleName = "G6_ADMIN"


                    Dim connection2 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
                    Dim updateAdminLogin As SqlCommand = New SqlCommand("INSERT INTO [dbo].[logs_tbl] ([Username],[Role],[DateTimeIn]) VALUES('" + txtUserName.Text + "','" + role + "','" + dateTimeIn + "')", connection)

                    connection2.Open()
                    updateAdminLogin.ExecuteNonQuery()
                    connection2.Close()

                    Me.Hide()
                    adminPage.Show()

                Else
                    MessageBox.Show("Invalid Username or Password.", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

                connection.Close()

                Profile.timeIn = dateTimeIn
                adminPage.adminTimeIn = dateTimeIn

            End Using
        End Using

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Dim Homepage As frmHomepage
        Homepage = New frmHomepage

        txtUserName.Clear()
        txtPass.Clear()

        Me.Hide()
        Homepage.Show()

    End Sub

End Class