﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblGRP6 = New System.Windows.Forms.Label()
        Me.tmrAdmin = New System.Windows.Forms.Timer(Me.components)
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.grpCount = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.lblB7BHS = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.lblStaAna = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.lblSMAURA = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.lblAfternoon = New System.Windows.Forms.Label()
        Me.lblMorning = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblC1 = New System.Windows.Forms.Label()
        Me.lblB6 = New System.Windows.Forms.Label()
        Me.lblB5 = New System.Windows.Forms.Label()
        Me.lblB4 = New System.Windows.Forms.Label()
        Me.lblB3 = New System.Windows.Forms.Label()
        Me.lblB2 = New System.Windows.Forms.Label()
        Me.lblB1 = New System.Windows.Forms.Label()
        Me.lblA5 = New System.Windows.Forms.Label()
        Me.lblA4 = New System.Windows.Forms.Label()
        Me.lblA3 = New System.Windows.Forms.Label()
        Me.lblA2 = New System.Windows.Forms.Label()
        Me.lblA1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblJohnson = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblAstra = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblSputnik = New System.Windows.Forms.Label()
        Me.lblPfizer = New System.Windows.Forms.Label()
        Me.lblModerna = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblAppointments = New System.Windows.Forms.Label()
        Me.lbl1stDose = New System.Windows.Forms.Label()
        Me.lbl2ndDose = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblAccounts = New System.Windows.Forms.Label()
        Me.lblClock = New System.Windows.Forms.Label()
        Me.lblPlease = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.btnViewLogs = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.btnViewAppointments = New System.Windows.Forms.Button()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btnViewUser = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtLastname = New System.Windows.Forms.TextBox()
        Me.dgvSearchTable = New System.Windows.Forms.DataGridView()
        Me.grpCount.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.dgvSearchTable, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblGRP6
        '
        Me.lblGRP6.AutoSize = True
        Me.lblGRP6.BackColor = System.Drawing.Color.Transparent
        Me.lblGRP6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGRP6.ForeColor = System.Drawing.Color.White
        Me.lblGRP6.Location = New System.Drawing.Point(12, 9)
        Me.lblGRP6.Name = "lblGRP6"
        Me.lblGRP6.Size = New System.Drawing.Size(279, 24)
        Me.lblGRP6.TabIndex = 71
        Me.lblGRP6.Text = "Group 6 : Vaccination System"
        '
        'tmrAdmin
        '
        Me.tmrAdmin.Enabled = True
        Me.tmrAdmin.Interval = 1000
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTime.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.White
        Me.lblDateTime.Location = New System.Drawing.Point(1230, 9)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(148, 18)
        Me.lblDateTime.TabIndex = 72
        Me.lblDateTime.Text = "                                   "
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Red
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogOut.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.Black
        Me.btnLogOut.Location = New System.Drawing.Point(1103, 719)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(250, 65)
        Me.btnLogOut.TabIndex = 73
        Me.btnLogOut.Text = "LOG-OUT"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'grpCount
        '
        Me.grpCount.BackColor = System.Drawing.Color.Transparent
        Me.grpCount.Controls.Add(Me.GroupBox6)
        Me.grpCount.Controls.Add(Me.GroupBox5)
        Me.grpCount.Controls.Add(Me.GroupBox2)
        Me.grpCount.Controls.Add(Me.GroupBox4)
        Me.grpCount.Controls.Add(Me.GroupBox3)
        Me.grpCount.Controls.Add(Me.GroupBox1)
        Me.grpCount.Font = New System.Drawing.Font("Raleway", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpCount.ForeColor = System.Drawing.Color.White
        Me.grpCount.Location = New System.Drawing.Point(37, 152)
        Me.grpCount.Name = "grpCount"
        Me.grpCount.Size = New System.Drawing.Size(766, 637)
        Me.grpCount.TabIndex = 74
        Me.grpCount.TabStop = False
        Me.grpCount.Text = "AS OF:"
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox6.Controls.Add(Me.Label42)
        Me.GroupBox6.Controls.Add(Me.Label43)
        Me.GroupBox6.Controls.Add(Me.lblB7BHS)
        Me.GroupBox6.Controls.Add(Me.Label47)
        Me.GroupBox6.Controls.Add(Me.Label34)
        Me.GroupBox6.Controls.Add(Me.Label37)
        Me.GroupBox6.Controls.Add(Me.lblStaAna)
        Me.GroupBox6.Controls.Add(Me.Label39)
        Me.GroupBox6.Controls.Add(Me.Label41)
        Me.GroupBox6.Controls.Add(Me.Label40)
        Me.GroupBox6.Controls.Add(Me.lblSMAURA)
        Me.GroupBox6.Controls.Add(Me.Label36)
        Me.GroupBox6.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.White
        Me.GroupBox6.Location = New System.Drawing.Point(517, 179)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(219, 433)
        Me.GroupBox6.TabIndex = 116
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Vaccination Site:"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(20, 394)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(95, 24)
        Me.Label42.TabIndex = 116
        Me.Label42.Text = "VaccHub"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(40, 370)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(54, 24)
        Me.Label43.TabIndex = 115
        Me.Label43.Text = "BHS:"
        '
        'lblB7BHS
        '
        Me.lblB7BHS.AutoSize = True
        Me.lblB7BHS.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB7BHS.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB7BHS.Location = New System.Drawing.Point(171, 370)
        Me.lblB7BHS.Name = "lblB7BHS"
        Me.lblB7BHS.Size = New System.Drawing.Size(26, 24)
        Me.lblB7BHS.TabIndex = 113
        Me.lblB7BHS.Text = "--"
        Me.lblB7BHS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(50, 346)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(34, 24)
        Me.Label47.TabIndex = 114
        Me.Label47.Text = "B7"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(44, 265)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(46, 24)
        Me.Label34.TabIndex = 112
        Me.Label34.Text = "Hall"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(16, 240)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(102, 24)
        Me.Label37.TabIndex = 111
        Me.Label37.Text = "Barangay:"
        '
        'lblStaAna
        '
        Me.lblStaAna.AutoSize = True
        Me.lblStaAna.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStaAna.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStaAna.Location = New System.Drawing.Point(171, 240)
        Me.lblStaAna.Name = "lblStaAna"
        Me.lblStaAna.Size = New System.Drawing.Size(26, 24)
        Me.lblStaAna.TabIndex = 109
        Me.lblStaAna.Text = "--"
        Me.lblStaAna.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(25, 215)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(85, 24)
        Me.Label39.TabIndex = 110
        Me.Label39.Text = "Sta. Ana"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(44, 135)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(46, 24)
        Me.Label41.TabIndex = 108
        Me.Label41.Text = "Hall"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(17, 110)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(101, 24)
        Me.Label40.TabIndex = 107
        Me.Label40.Text = "Samsung:"
        '
        'lblSMAURA
        '
        Me.lblSMAURA.AutoSize = True
        Me.lblSMAURA.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSMAURA.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblSMAURA.Location = New System.Drawing.Point(171, 110)
        Me.lblSMAURA.Name = "lblSMAURA"
        Me.lblSMAURA.Size = New System.Drawing.Size(26, 24)
        Me.lblSMAURA.TabIndex = 89
        Me.lblSMAURA.Text = "--"
        Me.lblSMAURA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(18, 85)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(99, 24)
        Me.Label36.TabIndex = 93
        Me.Label36.Text = "SM AURA"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox5.Controls.Add(Me.lblAfternoon)
        Me.GroupBox5.Controls.Add(Me.lblMorning)
        Me.GroupBox5.Controls.Add(Me.Label49)
        Me.GroupBox5.Controls.Add(Me.Label52)
        Me.GroupBox5.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.White
        Me.GroupBox5.Location = New System.Drawing.Point(517, 45)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(219, 131)
        Me.GroupBox5.TabIndex = 115
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Time Slot:"
        '
        'lblAfternoon
        '
        Me.lblAfternoon.AutoSize = True
        Me.lblAfternoon.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAfternoon.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblAfternoon.Location = New System.Drawing.Point(171, 91)
        Me.lblAfternoon.Name = "lblAfternoon"
        Me.lblAfternoon.Size = New System.Drawing.Size(26, 24)
        Me.lblAfternoon.TabIndex = 104
        Me.lblAfternoon.Text = "--"
        Me.lblAfternoon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMorning
        '
        Me.lblMorning.AutoSize = True
        Me.lblMorning.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMorning.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblMorning.Location = New System.Drawing.Point(171, 47)
        Me.lblMorning.Name = "lblMorning"
        Me.lblMorning.Size = New System.Drawing.Size(26, 24)
        Me.lblMorning.TabIndex = 89
        Me.lblMorning.Text = "--"
        Me.lblMorning.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(18, 47)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(91, 24)
        Me.Label49.TabIndex = 93
        Me.Label49.Text = "Morning:"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(18, 91)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(109, 24)
        Me.Label52.TabIndex = 94
        Me.Label52.Text = "Afternoon:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.lblC1)
        Me.GroupBox2.Controls.Add(Me.lblB6)
        Me.GroupBox2.Controls.Add(Me.lblB5)
        Me.GroupBox2.Controls.Add(Me.lblB4)
        Me.GroupBox2.Controls.Add(Me.lblB3)
        Me.GroupBox2.Controls.Add(Me.lblB2)
        Me.GroupBox2.Controls.Add(Me.lblB1)
        Me.GroupBox2.Controls.Add(Me.lblA5)
        Me.GroupBox2.Controls.Add(Me.lblA4)
        Me.GroupBox2.Controls.Add(Me.lblA3)
        Me.GroupBox2.Controls.Add(Me.lblA2)
        Me.GroupBox2.Controls.Add(Me.lblA1)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(272, 45)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(219, 567)
        Me.GroupBox2.TabIndex = 105
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Priority Level:"
        '
        'lblC1
        '
        Me.lblC1.AutoSize = True
        Me.lblC1.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblC1.Location = New System.Drawing.Point(171, 522)
        Me.lblC1.Name = "lblC1"
        Me.lblC1.Size = New System.Drawing.Size(26, 24)
        Me.lblC1.TabIndex = 114
        Me.lblC1.Text = "--"
        Me.lblC1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblB6
        '
        Me.lblB6.AutoSize = True
        Me.lblB6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB6.Location = New System.Drawing.Point(171, 478)
        Me.lblB6.Name = "lblB6"
        Me.lblB6.Size = New System.Drawing.Size(26, 24)
        Me.lblB6.TabIndex = 113
        Me.lblB6.Text = "--"
        Me.lblB6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblB5
        '
        Me.lblB5.AutoSize = True
        Me.lblB5.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB5.Location = New System.Drawing.Point(171, 435)
        Me.lblB5.Name = "lblB5"
        Me.lblB5.Size = New System.Drawing.Size(26, 24)
        Me.lblB5.TabIndex = 112
        Me.lblB5.Text = "--"
        Me.lblB5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblB4
        '
        Me.lblB4.AutoSize = True
        Me.lblB4.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB4.Location = New System.Drawing.Point(171, 392)
        Me.lblB4.Name = "lblB4"
        Me.lblB4.Size = New System.Drawing.Size(26, 24)
        Me.lblB4.TabIndex = 111
        Me.lblB4.Text = "--"
        Me.lblB4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblB3
        '
        Me.lblB3.AutoSize = True
        Me.lblB3.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB3.Location = New System.Drawing.Point(171, 349)
        Me.lblB3.Name = "lblB3"
        Me.lblB3.Size = New System.Drawing.Size(26, 24)
        Me.lblB3.TabIndex = 110
        Me.lblB3.Text = "--"
        Me.lblB3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblB2
        '
        Me.lblB2.AutoSize = True
        Me.lblB2.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB2.Location = New System.Drawing.Point(171, 306)
        Me.lblB2.Name = "lblB2"
        Me.lblB2.Size = New System.Drawing.Size(26, 24)
        Me.lblB2.TabIndex = 109
        Me.lblB2.Text = "--"
        Me.lblB2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblB1
        '
        Me.lblB1.AutoSize = True
        Me.lblB1.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblB1.Location = New System.Drawing.Point(171, 263)
        Me.lblB1.Name = "lblB1"
        Me.lblB1.Size = New System.Drawing.Size(26, 24)
        Me.lblB1.TabIndex = 108
        Me.lblB1.Text = "--"
        Me.lblB1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblA5
        '
        Me.lblA5.AutoSize = True
        Me.lblA5.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblA5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblA5.Location = New System.Drawing.Point(171, 220)
        Me.lblA5.Name = "lblA5"
        Me.lblA5.Size = New System.Drawing.Size(26, 24)
        Me.lblA5.TabIndex = 107
        Me.lblA5.Text = "--"
        Me.lblA5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblA4
        '
        Me.lblA4.AutoSize = True
        Me.lblA4.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblA4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblA4.Location = New System.Drawing.Point(171, 177)
        Me.lblA4.Name = "lblA4"
        Me.lblA4.Size = New System.Drawing.Size(26, 24)
        Me.lblA4.TabIndex = 106
        Me.lblA4.Text = "--"
        Me.lblA4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblA3
        '
        Me.lblA3.AutoSize = True
        Me.lblA3.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblA3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblA3.Location = New System.Drawing.Point(171, 134)
        Me.lblA3.Name = "lblA3"
        Me.lblA3.Size = New System.Drawing.Size(26, 24)
        Me.lblA3.TabIndex = 105
        Me.lblA3.Text = "--"
        Me.lblA3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblA2
        '
        Me.lblA2.AutoSize = True
        Me.lblA2.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblA2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblA2.Location = New System.Drawing.Point(171, 91)
        Me.lblA2.Name = "lblA2"
        Me.lblA2.Size = New System.Drawing.Size(26, 24)
        Me.lblA2.TabIndex = 104
        Me.lblA2.Text = "--"
        Me.lblA2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblA1
        '
        Me.lblA1.AutoSize = True
        Me.lblA1.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblA1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblA1.Location = New System.Drawing.Point(171, 47)
        Me.lblA1.Name = "lblA1"
        Me.lblA1.Size = New System.Drawing.Size(26, 24)
        Me.lblA1.TabIndex = 89
        Me.lblA1.Text = "--"
        Me.lblA1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(18, 177)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(39, 24)
        Me.Label11.TabIndex = 94
        Me.Label11.Text = "A4:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(18, 478)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(39, 24)
        Me.Label18.TabIndex = 103
        Me.Label18.Text = "B6:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(18, 349)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(38, 24)
        Me.Label16.TabIndex = 98
        Me.Label16.Text = "B3:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(18, 47)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 24)
        Me.Label10.TabIndex = 93
        Me.Label10.Text = "A1:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(18, 306)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 24)
        Me.Label14.TabIndex = 99
        Me.Label14.Text = "B2:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(18, 392)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(38, 24)
        Me.Label21.TabIndex = 100
        Me.Label21.Text = "B4:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(18, 91)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 24)
        Me.Label12.TabIndex = 94
        Me.Label12.Text = "A2:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(18, 263)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(36, 24)
        Me.Label15.TabIndex = 97
        Me.Label15.Text = "B1:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(18, 220)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(39, 24)
        Me.Label17.TabIndex = 96
        Me.Label17.Text = "A5:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(18, 435)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(38, 24)
        Me.Label19.TabIndex = 101
        Me.Label19.Text = "B5:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(18, 522)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(37, 24)
        Me.Label20.TabIndex = 102
        Me.Label20.Text = "C1:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(18, 134)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(39, 24)
        Me.Label13.TabIndex = 95
        Me.Label13.Text = "A3:"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.lblJohnson)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.lblAstra)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.lblSputnik)
        Me.GroupBox4.Controls.Add(Me.lblPfizer)
        Me.GroupBox4.Controls.Add(Me.lblModerna)
        Me.GroupBox4.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.White
        Me.GroupBox4.Location = New System.Drawing.Point(29, 294)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(219, 318)
        Me.GroupBox4.TabIndex = 106
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Vaccine"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(13, 219)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(102, 24)
        Me.Label7.TabIndex = 82
        Me.Label7.Text = "Sputnik V:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 24)
        Me.Label5.TabIndex = 80
        Me.Label5.Text = "Pfizer:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 111)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 24)
        Me.Label6.TabIndex = 81
        Me.Label6.Text = "Moderna:"
        '
        'lblJohnson
        '
        Me.lblJohnson.AutoSize = True
        Me.lblJohnson.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJohnson.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblJohnson.Location = New System.Drawing.Point(176, 273)
        Me.lblJohnson.Name = "lblJohnson"
        Me.lblJohnson.Size = New System.Drawing.Size(26, 24)
        Me.lblJohnson.TabIndex = 92
        Me.lblJohnson.Text = "--"
        Me.lblJohnson.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(13, 165)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(134, 24)
        Me.Label8.TabIndex = 83
        Me.Label8.Text = "AstraZeneca:"
        '
        'lblAstra
        '
        Me.lblAstra.AutoSize = True
        Me.lblAstra.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAstra.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblAstra.Location = New System.Drawing.Point(176, 165)
        Me.lblAstra.Name = "lblAstra"
        Me.lblAstra.Size = New System.Drawing.Size(26, 24)
        Me.lblAstra.TabIndex = 91
        Me.lblAstra.Text = "--"
        Me.lblAstra.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(13, 273)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 24)
        Me.Label9.TabIndex = 84
        Me.Label9.Text = "J.Johnson:"
        '
        'lblSputnik
        '
        Me.lblSputnik.AutoSize = True
        Me.lblSputnik.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSputnik.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblSputnik.Location = New System.Drawing.Point(176, 219)
        Me.lblSputnik.Name = "lblSputnik"
        Me.lblSputnik.Size = New System.Drawing.Size(26, 24)
        Me.lblSputnik.TabIndex = 91
        Me.lblSputnik.Text = "--"
        Me.lblSputnik.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblPfizer
        '
        Me.lblPfizer.AutoSize = True
        Me.lblPfizer.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPfizer.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblPfizer.Location = New System.Drawing.Point(176, 57)
        Me.lblPfizer.Name = "lblPfizer"
        Me.lblPfizer.Size = New System.Drawing.Size(26, 24)
        Me.lblPfizer.TabIndex = 89
        Me.lblPfizer.Text = "--"
        Me.lblPfizer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblModerna
        '
        Me.lblModerna.AutoSize = True
        Me.lblModerna.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModerna.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblModerna.Location = New System.Drawing.Point(176, 111)
        Me.lblModerna.Name = "lblModerna"
        Me.lblModerna.Size = New System.Drawing.Size(26, 24)
        Me.lblModerna.TabIndex = 90
        Me.lblModerna.Text = "--"
        Me.lblModerna.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.lblAppointments)
        Me.GroupBox3.Controls.Add(Me.lbl1stDose)
        Me.GroupBox3.Controls.Add(Me.lbl2ndDose)
        Me.GroupBox3.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(29, 117)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(219, 171)
        Me.GroupBox3.TabIndex = 105
        Me.GroupBox3.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(146, 24)
        Me.Label4.TabIndex = 79
        Me.Label4.Text = "Appointments:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 24)
        Me.Label2.TabIndex = 77
        Me.Label2.Text = "1st Dose:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 131)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(101, 24)
        Me.Label3.TabIndex = 78
        Me.Label3.Text = "2nd Dose:"
        '
        'lblAppointments
        '
        Me.lblAppointments.AutoSize = True
        Me.lblAppointments.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAppointments.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblAppointments.Location = New System.Drawing.Point(176, 35)
        Me.lblAppointments.Name = "lblAppointments"
        Me.lblAppointments.Size = New System.Drawing.Size(26, 24)
        Me.lblAppointments.TabIndex = 86
        Me.lblAppointments.Text = "--"
        Me.lblAppointments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl1stDose
        '
        Me.lbl1stDose.AutoSize = True
        Me.lbl1stDose.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stDose.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lbl1stDose.Location = New System.Drawing.Point(176, 83)
        Me.lbl1stDose.Name = "lbl1stDose"
        Me.lbl1stDose.Size = New System.Drawing.Size(26, 24)
        Me.lbl1stDose.TabIndex = 87
        Me.lbl1stDose.Text = "--"
        Me.lbl1stDose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl2ndDose
        '
        Me.lbl2ndDose.AutoSize = True
        Me.lbl2ndDose.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndDose.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lbl2ndDose.Location = New System.Drawing.Point(176, 131)
        Me.lbl2ndDose.Name = "lbl2ndDose"
        Me.lbl2ndDose.Size = New System.Drawing.Size(26, 24)
        Me.lbl2ndDose.TabIndex = 88
        Me.lbl2ndDose.Text = "--"
        Me.lbl2ndDose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblAccounts)
        Me.GroupBox1.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(29, 45)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(219, 66)
        Me.GroupBox1.TabIndex = 104
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 24)
        Me.Label1.TabIndex = 76
        Me.Label1.Text = "Accounts:"
        '
        'lblAccounts
        '
        Me.lblAccounts.AutoSize = True
        Me.lblAccounts.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccounts.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblAccounts.Location = New System.Drawing.Point(175, 28)
        Me.lblAccounts.Name = "lblAccounts"
        Me.lblAccounts.Size = New System.Drawing.Size(26, 24)
        Me.lblAccounts.TabIndex = 85
        Me.lblAccounts.Text = "--"
        Me.lblAccounts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblClock
        '
        Me.lblClock.AutoSize = True
        Me.lblClock.BackColor = System.Drawing.Color.Transparent
        Me.lblClock.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClock.ForeColor = System.Drawing.Color.White
        Me.lblClock.Location = New System.Drawing.Point(1230, 9)
        Me.lblClock.Name = "lblClock"
        Me.lblClock.Size = New System.Drawing.Size(148, 18)
        Me.lblClock.TabIndex = 75
        Me.lblClock.Text = "                                   "
        '
        'lblPlease
        '
        Me.lblPlease.AutoSize = True
        Me.lblPlease.BackColor = System.Drawing.Color.Transparent
        Me.lblPlease.Font = New System.Drawing.Font("Raleway", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlease.ForeColor = System.Drawing.Color.White
        Me.lblPlease.Location = New System.Drawing.Point(482, 19)
        Me.lblPlease.Name = "lblPlease"
        Me.lblPlease.Size = New System.Drawing.Size(419, 16)
        Me.lblPlease.TabIndex = 76
        Me.lblPlease.Text = "BSIT - 201I | Group 6 | Vaccination Registry System | ITC - C502"
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox7.Controls.Add(Me.GroupBox10)
        Me.GroupBox7.Controls.Add(Me.GroupBox9)
        Me.GroupBox7.Controls.Add(Me.GroupBox8)
        Me.GroupBox7.Font = New System.Drawing.Font("Raleway", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.Color.White
        Me.GroupBox7.Location = New System.Drawing.Point(823, 152)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(530, 549)
        Me.GroupBox7.TabIndex = 116
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "TABLES"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label24)
        Me.GroupBox10.Controls.Add(Me.btnViewLogs)
        Me.GroupBox10.Location = New System.Drawing.Point(29, 359)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(470, 160)
        Me.GroupBox10.TabIndex = 1
        Me.GroupBox10.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(86, 70)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 31)
        Me.Label24.TabIndex = 120
        Me.Label24.Text = "LOGS"
        '
        'btnViewLogs
        '
        Me.btnViewLogs.BackColor = System.Drawing.Color.White
        Me.btnViewLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewLogs.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewLogs.ForeColor = System.Drawing.Color.Black
        Me.btnViewLogs.Location = New System.Drawing.Point(251, 56)
        Me.btnViewLogs.Name = "btnViewLogs"
        Me.btnViewLogs.Size = New System.Drawing.Size(189, 65)
        Me.btnViewLogs.TabIndex = 120
        Me.btnViewLogs.Text = "VIEW TABLE"
        Me.btnViewLogs.UseVisualStyleBackColor = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label23)
        Me.GroupBox9.Controls.Add(Me.btnViewAppointments)
        Me.GroupBox9.Location = New System.Drawing.Point(29, 199)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(470, 160)
        Me.GroupBox9.TabIndex = 1
        Me.GroupBox9.TabStop = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(17, 70)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(223, 31)
        Me.Label23.TabIndex = 120
        Me.Label23.Text = "APPOINTMENTS"
        '
        'btnViewAppointments
        '
        Me.btnViewAppointments.BackColor = System.Drawing.Color.White
        Me.btnViewAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewAppointments.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewAppointments.ForeColor = System.Drawing.Color.Black
        Me.btnViewAppointments.Location = New System.Drawing.Point(251, 56)
        Me.btnViewAppointments.Name = "btnViewAppointments"
        Me.btnViewAppointments.Size = New System.Drawing.Size(189, 65)
        Me.btnViewAppointments.TabIndex = 119
        Me.btnViewAppointments.Text = "VIEW TABLE"
        Me.btnViewAppointments.UseVisualStyleBackColor = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label22)
        Me.GroupBox8.Controls.Add(Me.btnViewUser)
        Me.GroupBox8.Location = New System.Drawing.Point(29, 39)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(470, 160)
        Me.GroupBox8.TabIndex = 0
        Me.GroupBox8.TabStop = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(9, 70)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(238, 31)
        Me.Label22.TabIndex = 119
        Me.Label22.Text = "USER ACCOUNTS"
        '
        'btnViewUser
        '
        Me.btnViewUser.BackColor = System.Drawing.Color.White
        Me.btnViewUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewUser.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewUser.ForeColor = System.Drawing.Color.Black
        Me.btnViewUser.Location = New System.Drawing.Point(251, 56)
        Me.btnViewUser.Name = "btnViewUser"
        Me.btnViewUser.Size = New System.Drawing.Size(189, 65)
        Me.btnViewUser.TabIndex = 118
        Me.btnViewUser.Text = "VIEW TABLE"
        Me.btnViewUser.UseVisualStyleBackColor = False
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.White
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefresh.ForeColor = System.Drawing.Color.Black
        Me.btnRefresh.Location = New System.Drawing.Point(823, 719)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(250, 65)
        Me.btnRefresh.TabIndex = 117
        Me.btnRefresh.Text = "REFRESH"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'GroupBox11
        '
        Me.GroupBox11.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox11.Controls.Add(Me.btnSearch)
        Me.GroupBox11.Controls.Add(Me.txtLastname)
        Me.GroupBox11.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.ForeColor = System.Drawing.Color.White
        Me.GroupBox11.Location = New System.Drawing.Point(37, 46)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(342, 99)
        Me.GroupBox11.TabIndex = 118
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Search by Lastname"
        '
        'btnSearch
        '
        Me.btnSearch.BackColor = System.Drawing.Color.White
        Me.btnSearch.BackgroundImage = Global.VaccineSystem_Group6.My.Resources.Resources.searchButton
        Me.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSearch.Enabled = False
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.Black
        Me.btnSearch.Location = New System.Drawing.Point(272, 30)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(50, 50)
        Me.btnSearch.TabIndex = 120
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'txtLastname
        '
        Me.txtLastname.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastname.Location = New System.Drawing.Point(29, 39)
        Me.txtLastname.Name = "txtLastname"
        Me.txtLastname.Size = New System.Drawing.Size(225, 31)
        Me.txtLastname.TabIndex = 0
        Me.txtLastname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvSearchTable
        '
        Me.dgvSearchTable.AllowUserToAddRows = False
        Me.dgvSearchTable.AllowUserToDeleteRows = False
        Me.dgvSearchTable.AllowUserToResizeColumns = False
        Me.dgvSearchTable.AllowUserToResizeRows = False
        Me.dgvSearchTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvSearchTable.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvSearchTable.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSearchTable.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvSearchTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Raleway", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSearchTable.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvSearchTable.Location = New System.Drawing.Point(392, 57)
        Me.dgvSearchTable.Name = "dgvSearchTable"
        Me.dgvSearchTable.ReadOnly = True
        Me.dgvSearchTable.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.dgvSearchTable.Size = New System.Drawing.Size(961, 88)
        Me.dgvSearchTable.TabIndex = 119
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.VaccineSystem_Group6.My.Resources.Resources.BG_WITH_STRIPE
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1390, 840)
        Me.Controls.Add(Me.dgvSearchTable)
        Me.Controls.Add(Me.lblPlease)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.lblClock)
        Me.Controls.Add(Me.grpCount)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.lblDateTime)
        Me.Controls.Add(Me.lblGRP6)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmAdmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "G6 | Vaccination System | Admin Page"
        Me.grpCount.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.dgvSearchTable, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGRP6 As Label
    Friend WithEvents tmrAdmin As Timer
    Friend WithEvents lblDateTime As Label
    Friend WithEvents btnLogOut As Button
    Friend WithEvents grpCount As GroupBox
    Friend WithEvents lblClock As Label
    Friend WithEvents lblJohnson As Label
    Friend WithEvents lblAstra As Label
    Friend WithEvents lblSputnik As Label
    Friend WithEvents lblModerna As Label
    Friend WithEvents lblPfizer As Label
    Friend WithEvents lbl2ndDose As Label
    Friend WithEvents lbl1stDose As Label
    Friend WithEvents lblAppointments As Label
    Friend WithEvents lblAccounts As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblC1 As Label
    Friend WithEvents lblB6 As Label
    Friend WithEvents lblB5 As Label
    Friend WithEvents lblB4 As Label
    Friend WithEvents lblB3 As Label
    Friend WithEvents lblB2 As Label
    Friend WithEvents lblB1 As Label
    Friend WithEvents lblA5 As Label
    Friend WithEvents lblA4 As Label
    Friend WithEvents lblA3 As Label
    Friend WithEvents lblA2 As Label
    Friend WithEvents lblA1 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents lblB7BHS As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents lblStaAna As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents lblSMAURA As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents lblAfternoon As Label
    Friend WithEvents lblMorning As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents lblPlease As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents btnRefresh As Button
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents btnViewLogs As Button
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents btnViewAppointments As Button
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents btnViewUser As Button
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtLastname As TextBox
    Friend WithEvents dgvSearchTable As DataGridView
End Class
