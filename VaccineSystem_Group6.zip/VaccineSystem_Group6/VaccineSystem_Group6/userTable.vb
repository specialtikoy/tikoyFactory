﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmUserTable

    Private Sub frmUserTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowUserTable()

    End Sub

    Private Sub ShowUserTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[user_tbl] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvUserTable.DataSource = table

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

End Class