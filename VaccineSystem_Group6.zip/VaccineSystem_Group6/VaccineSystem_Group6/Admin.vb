﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmAdmin

    Public Property adminTimeIn As String

    Public roleName As String

    Dim adminPurpose As String

    Private Sub tmrAdmin_Tick(sender As Object, e As EventArgs) Handles tmrAdmin.Tick

        lblClock.Text = DateTime.Now

        If txtLastname.Text <> "" Then
            btnSearch.Enabled = True
            btnSearch.BackColor = Color.Lime
        Else
            btnSearch.Enabled = False
            btnSearch.BackColor = Color.White
        End If

    End Sub

    Private Sub frmAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        countTracker()

    End Sub

    Private Sub countTracker()

        grpCount.Text = "AS OF: " + DateTime.Now.ToString

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Using countAccounts As SqlCommand = New SqlCommand("SELECT COUNT([Account_Id]) FROM [dbo].[user_tbl] ", connection)
            Using countAppointments As SqlCommand = New SqlCommand("SELECT COUNT([Appointment_Id]) FROM [dbo].[appointments_tbl] ", connection)
                Using count1stDose As SqlCommand = New SqlCommand("SELECT COUNT([Dose]) FROM [dbo].[appointments_tbl] WHERE [DOSE] = '" + "1st Dose" + "' ", connection)
                    Using count2ndDose As SqlCommand = New SqlCommand("SELECT COUNT([Dose]) FROM [dbo].[appointments_tbl] WHERE [DOSE] = '" + "2nd Dose" + "' ", connection)
                        Using countPfizer As SqlCommand = New SqlCommand("SELECT COUNT([Vaccine_Brand]) FROM [dbo].[appointments_tbl] WHERE [Vaccine_Brand] = '" + "Pfizer" + "' ", connection)
                            Using countModerna As SqlCommand = New SqlCommand("SELECT COUNT([Vaccine_Brand]) FROM [dbo].[appointments_tbl] WHERE [Vaccine_Brand] = '" + "Moderna" + "' ", connection)
                                Using countAstra As SqlCommand = New SqlCommand("SELECT COUNT([Vaccine_Brand]) FROM [dbo].[appointments_tbl] WHERE [Vaccine_Brand] = '" + "AstraZeneca" + "' ", connection)
                                    Using countSputnik As SqlCommand = New SqlCommand("SELECT COUNT([Vaccine_Brand]) FROM [dbo].[appointments_tbl] WHERE [Vaccine_Brand] = '" + "Sputnik V" + "' ", connection)
                                        Using countJohnson As SqlCommand = New SqlCommand("SELECT COUNT([Vaccine_Brand]) FROM [dbo].[appointments_tbl] WHERE [Vaccine_Brand] = '" + "Johnson & Johnson" + "' ", connection)
                                            Using countA1 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "A1" + "' ", connection)
                                                Using countA2 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "A2" + "' ", connection)
                                                    Using countA3 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "A3" + "' ", connection)
                                                        Using countA4 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "A4" + "' ", connection)
                                                            Using countA5 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "A5" + "' ", connection)
                                                                Using countB1 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "B1" + "' ", connection)
                                                                    Using countB2 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "B2" + "' ", connection)
                                                                        Using countB3 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "B3" + "' ", connection)
                                                                            Using countB4 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "B4" + "' ", connection)
                                                                                Using countB5 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "B5" + "' ", connection)
                                                                                    Using countB6 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "B6" + "' ", connection)
                                                                                        Using countC1 As SqlCommand = New SqlCommand("SELECT COUNT([Priority_Level]) FROM [dbo].[appointments_tbl] WHERE [Priority_Level] = '" + "C1" + "' ", connection)
                                                                                            Using countMorning As SqlCommand = New SqlCommand("SELECT COUNT([Time_Slot]) FROM [dbo].[appointments_tbl] WHERE [Time_Slot] = '" + "8:00 AM - 12:00 PM" + "' ", connection)
                                                                                                Using countAfternoon As SqlCommand = New SqlCommand("SELECT COUNT([Time_Slot]) FROM [dbo].[appointments_tbl] WHERE [Time_Slot] = '" + "1:00 PM - 3:00 PM" + "' ", connection)
                                                                                                    Using countSM As SqlCommand = New SqlCommand("SELECT COUNT([Vaccination_Site]) FROM [dbo].[appointments_tbl] WHERE [Vaccination_Site] = '" + "SM AURA Samsung Hall" + "' ", connection)
                                                                                                        Using countStaAna As SqlCommand = New SqlCommand("SELECT COUNT([Vaccination_Site]) FROM [dbo].[appointments_tbl] WHERE [Vaccination_Site] = '" + "Sta. Ana Brgy. Hall" + "' ", connection)
                                                                                                            Using countB7BHS As SqlCommand = New SqlCommand("SELECT COUNT([Vaccination_Site]) FROM [dbo].[appointments_tbl] WHERE [Vaccination_Site] = '" + "B7 BHS VaccHub" + "' ", connection)

                                                                                                                connection.Open()
                                                                                                                lblAccounts.Text = countAccounts.ExecuteScalar()
                                                                                                                lblAppointments.Text = countAppointments.ExecuteScalar()
                                                                                                                lbl1stDose.Text = count1stDose.ExecuteScalar()
                                                                                                                lbl2ndDose.Text = count2ndDose.ExecuteScalar()
                                                                                                                lblPfizer.Text = countPfizer.ExecuteScalar()
                                                                                                                lblModerna.Text = countModerna.ExecuteScalar()
                                                                                                                lblAstra.Text = countAstra.ExecuteScalar()
                                                                                                                lblSputnik.Text = countSputnik.ExecuteScalar()
                                                                                                                lblJohnson.Text = countJohnson.ExecuteScalar()
                                                                                                                lblA1.Text = countA1.ExecuteScalar()
                                                                                                                lblA2.Text = countA2.ExecuteScalar()
                                                                                                                lblA3.Text = countA3.ExecuteScalar()
                                                                                                                lblA4.Text = countA4.ExecuteScalar()
                                                                                                                lblA5.Text = countA5.ExecuteScalar()
                                                                                                                lblB1.Text = countB1.ExecuteScalar()
                                                                                                                lblB2.Text = countB2.ExecuteScalar()
                                                                                                                lblB3.Text = countB3.ExecuteScalar()
                                                                                                                lblB4.Text = countB4.ExecuteScalar()
                                                                                                                lblB5.Text = countB5.ExecuteScalar()
                                                                                                                lblB6.Text = countB6.ExecuteScalar()
                                                                                                                lblC1.Text = countC1.ExecuteScalar()
                                                                                                                lblMorning.Text = countMorning.ExecuteScalar()
                                                                                                                lblAfternoon.Text = countAfternoon.ExecuteScalar()
                                                                                                                lblSMAURA.Text = countSM.ExecuteScalar()
                                                                                                                lblStaAna.Text = countStaAna.ExecuteScalar()
                                                                                                                lblB7BHS.Text = countB7BHS.ExecuteScalar()
                                                                                                                connection.Close()

                                                                                                            End Using
                                                                                                        End Using
                                                                                                    End Using
                                                                                                End Using
                                                                                            End Using
                                                                                        End Using
                                                                                    End Using
                                                                                End Using
                                                                            End Using
                                                                        End Using
                                                                    End Using
                                                                End Using
                                                            End Using
                                                        End Using
                                                    End Using
                                                End Using
                                            End Using
                                        End Using
                                    End Using
                                End Using
                            End Using
                        End Using
                    End Using
                End Using
            End Using
        End Using

    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click

        countTracker()

    End Sub

    Private Sub btnViewUser_Click(sender As Object, e As EventArgs) Handles btnViewUser.Click

        Dim userTable As frmUserTable
        userTable = New frmUserTable

        userTable.Show()

    End Sub

    Private Sub btnViewAppointments_Click(sender As Object, e As EventArgs) Handles btnViewAppointments.Click

        Dim apppointmentsTable As frmAppointmentsTable
        apppointmentsTable = New frmAppointmentsTable

        apppointmentsTable.Show()

    End Sub

    Private Sub btnViewLogs_Click(sender As Object, e As EventArgs) Handles btnViewLogs.Click

        Dim logsTable As frmLogsTable
        logsTable = New frmLogsTable

        logsTable.Show()

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        searchByLastName()

    End Sub

    Private Sub searchByLastName()

        Dim Lastname As String

        Lastname = txtLastname.Text

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[user_tbl] WHERE [Last_Name] = '" + Lastname + "' ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvSearchTable.DataSource = table

    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click

        adminPurpose = "File Maintenance"

        Dim question As DialogResult = MessageBox.Show("Are you sure you want to log-out?", "VACCINATION SYSTEM", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim connection2 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
            Dim updateAdminTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[logs_tbl] SET [Purpose] = '" + adminPurpose + "', [DateTimeOut] = '" + DateTime.Now.ToString + "' WHERE [Username] = '" + roleName + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [DateTimeIn] = '" + adminTimeIn + "'", connection2)

            connection2.Open()
            updateAdminTimeOutLog.ExecuteNonQuery()
            connection2.Close()

            Dim Homepage As frmHomepage
            Homepage = New frmHomepage

            Me.Close()
            Homepage.Show()

        End If

    End Sub

End Class