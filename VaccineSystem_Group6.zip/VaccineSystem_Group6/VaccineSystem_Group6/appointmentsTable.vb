﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmAppointmentsTable

    Private Sub frmAppointmentsTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowAppointmentsTable()

    End Sub

    Private Sub ShowAppointmentsTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[appointments_tbl] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvAppointmentsTable.DataSource = table

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

End Class