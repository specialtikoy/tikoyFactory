﻿Imports System.Data
Imports System.Data.SqlClient

Public Class frmAppointment

    Dim accountId, priorityLevel, vaccineBrand, vaccinationSite, timeSlot, appointmentDate, dose As String

    Public Property book2ndDose As Boolean


    Private Sub tmrAppointment_Tick(sender As Object, e As EventArgs) Handles tmrAppointment.Tick

        lblDateTime.Text = DateTime.Now
        dtpAppointmentDate.MinDate = DateTime.Today.AddDays(1)

        If txtEnterAccountId.Text = "" Or cboPriority.SelectedIndex = -1 Or cboVaccine.SelectedIndex = -1 Or
            cboSite.SelectedIndex = -1 Or cboTimeSlot.SelectedIndex = -1 Or cboDose.SelectedIndex = -1 Then
            btnBook.Enabled = False
        Else
            btnBook.Enabled = True
            btnBook.BackColor = Color.Lime
        End If

    End Sub

    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click

        accountId = txtEnterAccountId.Text

        If cboPriority.SelectedIndex = 0 Then
            priorityLevel = "A1"
        ElseIf cboPriority.SelectedIndex = 1 Then
            priorityLevel = "A2"
        ElseIf cboPriority.SelectedIndex = 2 Then
            priorityLevel = "A3"
        ElseIf cboPriority.SelectedIndex = 3 Then
            priorityLevel = "A4"
        ElseIf cboPriority.SelectedIndex = 4 Then
            priorityLevel = "A5"
        ElseIf cboPriority.SelectedIndex = 5 Then
            priorityLevel = "B1"
        ElseIf cboPriority.SelectedIndex = 6 Then
            priorityLevel = "B2"
        ElseIf cboPriority.SelectedIndex = 7 Then
            priorityLevel = "B3"
        ElseIf cboPriority.SelectedIndex = 8 Then
            priorityLevel = "B4"
        ElseIf cboPriority.SelectedIndex = 9 Then
            priorityLevel = "B5"
        ElseIf cboPriority.SelectedIndex = 10 Then
            priorityLevel = "B6"
        ElseIf cboPriority.SelectedIndex = 11 Then
            priorityLevel = "C1"
        End If

        If cboVaccine.SelectedIndex = 0 Then
            vaccineBrand = "Pfizer"
        ElseIf cboVaccine.SelectedIndex = 1 Then
            vaccineBrand = "Moderna"
        ElseIf cboVaccine.SelectedIndex = 2 Then
            vaccineBrand = "AstraZeneca"
        ElseIf cboVaccine.SelectedIndex = 3 Then
            vaccineBrand = "SinoVac"
        ElseIf cboVaccine.SelectedIndex = 4 Then
            vaccineBrand = "Sputnik V"
        ElseIf cboVaccine.SelectedIndex = 5 Then
            vaccineBrand = "Johnson & Johnson"
        End If

        If cboSite.SelectedIndex = 0 Then
            vaccinationSite = "SM AURA Samsung Hall"
        ElseIf cboSite.SelectedIndex = 1 Then
            vaccinationSite = "Sta. Ana Brgy. Hall"
        ElseIf cboSite.SelectedIndex = 2 Then
            vaccinationSite = "B7 BHS VaccHub"
        End If

        If cboTimeSlot.SelectedIndex = 0 Then
            timeSlot = "8:00 AM - 12:00 PM"
        ElseIf cboTimeSlot.SelectedIndex = 1 Then
            timeSlot = "1:00 PM - 3:00 PM"
        End If

        If cboDose.SelectedIndex = 0 Then
            dose = "1st Dose"
        ElseIf cboDose.SelectedIndex = 1 Then
            dose = "2nd Dose"
        End If

        appointmentDate = dtpAppointmentDate.Value.ToShortDateString

        Dim question As DialogResult = MessageBox.Show("Are all fields filled-up correctly?", "VACCINATION SYSTEM", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
            Dim insertIntoAppointmentsTableCmd As SqlCommand = New SqlCommand("INSERT INTO [dbo].[appointments_tbl] ([Vaccine_Brand],[Priority_Level],[Vaccination_Site],[Date],[Time_Slot],[Dose],[Account_Id])
                VALUES('" + vaccineBrand + "','" + priorityLevel + "','" + vaccinationSite + "','" + appointmentDate + "','" + timeSlot + "','" + dose + "','" + accountId + "')", connection)

            connection.Open()
            insertIntoAppointmentsTableCmd.ExecuteNonQuery()
            connection.Close()

            If cboDose.SelectedIndex = 0 Then

                Dim connection2 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
                Dim editFirstDoseDateCmd As SqlCommand = New SqlCommand("UPDATE [dbo].[user_tbl] SET [First_Dose] = '" + appointmentDate + "' WHERE [Account_Id] = '" + accountId + "'", connection2)

                connection2.Open()
                editFirstDoseDateCmd.ExecuteNonQuery()
                connection2.Close()

            ElseIf cboDose.SelectedIndex = 1 Then


                Dim connection3 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
                Dim editSecondtDoseDateCmd As SqlCommand = New SqlCommand("UPDATE [dbo].[user_tbl] SET [Second_Dose] = '" + appointmentDate + "' WHERE [Account_Id] = '" + accountId + "'", connection3)

                connection3.Open()
                editSecondtDoseDateCmd.ExecuteNonQuery()
                connection3.Close()


            End If


            Dim Homepage As frmHomepage
            Homepage = New frmHomepage

            MessageBox.Show("Thank you. Your appointment has been scheduled.", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Me.Hide()
            Homepage.Show()

        ElseIf question = DialogResult.No Then
            MessageBox.Show("Please check all fields thoroughly.", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If


    End Sub
End Class