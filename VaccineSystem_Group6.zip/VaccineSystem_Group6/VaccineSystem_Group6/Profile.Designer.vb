﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrProfile = New System.Windows.Forms.Timer(Me.components)
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.lblGRP6 = New System.Windows.Forms.Label()
        Me.grpProfile = New System.Windows.Forms.GroupBox()
        Me.lblAccountId = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblContactNumber = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblDateOfBirth = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblMiddleName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lbl2ndDoseVaccine = New System.Windows.Forms.Label()
        Me.lbl2ndDoseDate = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lbl1stDoseVaccine = New System.Windows.Forms.Label()
        Me.lbl1stDoseDate = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnBook = New System.Windows.Forms.Button()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.lblPlease = New System.Windows.Forms.Label()
        Me.grpProfile.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmrProfile
        '
        Me.tmrProfile.Enabled = True
        Me.tmrProfile.Interval = 1000
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTime.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.White
        Me.lblDateTime.Location = New System.Drawing.Point(1230, 9)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(148, 18)
        Me.lblDateTime.TabIndex = 4
        Me.lblDateTime.Text = "                                   "
        '
        'lblGRP6
        '
        Me.lblGRP6.AutoSize = True
        Me.lblGRP6.BackColor = System.Drawing.Color.Transparent
        Me.lblGRP6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGRP6.ForeColor = System.Drawing.Color.White
        Me.lblGRP6.Location = New System.Drawing.Point(12, 9)
        Me.lblGRP6.Name = "lblGRP6"
        Me.lblGRP6.Size = New System.Drawing.Size(279, 24)
        Me.lblGRP6.TabIndex = 5
        Me.lblGRP6.Text = "Group 6 : Vaccination System"
        '
        'grpProfile
        '
        Me.grpProfile.BackColor = System.Drawing.Color.Transparent
        Me.grpProfile.Controls.Add(Me.lblAccountId)
        Me.grpProfile.Controls.Add(Me.Label22)
        Me.grpProfile.Controls.Add(Me.lblGender)
        Me.grpProfile.Controls.Add(Me.lblContactNumber)
        Me.grpProfile.Controls.Add(Me.lblAddress)
        Me.grpProfile.Controls.Add(Me.lblDateOfBirth)
        Me.grpProfile.Controls.Add(Me.lblLastName)
        Me.grpProfile.Controls.Add(Me.lblMiddleName)
        Me.grpProfile.Controls.Add(Me.lblFirstName)
        Me.grpProfile.Controls.Add(Me.GroupBox2)
        Me.grpProfile.Controls.Add(Me.Label9)
        Me.grpProfile.Controls.Add(Me.Label4)
        Me.grpProfile.Controls.Add(Me.Label5)
        Me.grpProfile.Controls.Add(Me.Label6)
        Me.grpProfile.Controls.Add(Me.Label3)
        Me.grpProfile.Controls.Add(Me.Label2)
        Me.grpProfile.Controls.Add(Me.Label1)
        Me.grpProfile.Font = New System.Drawing.Font("Raleway", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpProfile.ForeColor = System.Drawing.Color.White
        Me.grpProfile.Location = New System.Drawing.Point(43, 72)
        Me.grpProfile.Name = "grpProfile"
        Me.grpProfile.Size = New System.Drawing.Size(1304, 501)
        Me.grpProfile.TabIndex = 30
        Me.grpProfile.TabStop = False
        '
        'lblAccountId
        '
        Me.lblAccountId.AutoSize = True
        Me.lblAccountId.BackColor = System.Drawing.Color.Transparent
        Me.lblAccountId.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccountId.ForeColor = System.Drawing.Color.White
        Me.lblAccountId.Location = New System.Drawing.Point(215, 70)
        Me.lblAccountId.Name = "lblAccountId"
        Me.lblAccountId.Size = New System.Drawing.Size(0, 24)
        Me.lblAccountId.TabIndex = 81
        Me.lblAccountId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(84, 70)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(119, 24)
        Me.Label22.TabIndex = 80
        Me.Label22.Text = "Account ID:"
        '
        'lblGender
        '
        Me.lblGender.AutoSize = True
        Me.lblGender.BackColor = System.Drawing.Color.Transparent
        Me.lblGender.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGender.ForeColor = System.Drawing.Color.White
        Me.lblGender.Location = New System.Drawing.Point(215, 441)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(0, 24)
        Me.lblGender.TabIndex = 79
        Me.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblContactNumber
        '
        Me.lblContactNumber.AutoSize = True
        Me.lblContactNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblContactNumber.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContactNumber.ForeColor = System.Drawing.Color.White
        Me.lblContactNumber.Location = New System.Drawing.Point(215, 388)
        Me.lblContactNumber.Name = "lblContactNumber"
        Me.lblContactNumber.Size = New System.Drawing.Size(0, 24)
        Me.lblContactNumber.TabIndex = 78
        Me.lblContactNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.Color.Transparent
        Me.lblAddress.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.ForeColor = System.Drawing.Color.White
        Me.lblAddress.Location = New System.Drawing.Point(215, 335)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(0, 24)
        Me.lblAddress.TabIndex = 77
        Me.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDateOfBirth
        '
        Me.lblDateOfBirth.AutoSize = True
        Me.lblDateOfBirth.BackColor = System.Drawing.Color.Transparent
        Me.lblDateOfBirth.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateOfBirth.ForeColor = System.Drawing.Color.White
        Me.lblDateOfBirth.Location = New System.Drawing.Point(215, 282)
        Me.lblDateOfBirth.Name = "lblDateOfBirth"
        Me.lblDateOfBirth.Size = New System.Drawing.Size(0, 24)
        Me.lblDateOfBirth.TabIndex = 76
        Me.lblDateOfBirth.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.BackColor = System.Drawing.Color.Transparent
        Me.lblLastName.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastName.ForeColor = System.Drawing.Color.White
        Me.lblLastName.Location = New System.Drawing.Point(215, 229)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(0, 24)
        Me.lblLastName.TabIndex = 75
        Me.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMiddleName
        '
        Me.lblMiddleName.AutoSize = True
        Me.lblMiddleName.BackColor = System.Drawing.Color.Transparent
        Me.lblMiddleName.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMiddleName.ForeColor = System.Drawing.Color.White
        Me.lblMiddleName.Location = New System.Drawing.Point(215, 176)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(0, 24)
        Me.lblMiddleName.TabIndex = 74
        Me.lblMiddleName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.BackColor = System.Drawing.Color.Transparent
        Me.lblFirstName.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.ForeColor = System.Drawing.Color.White
        Me.lblFirstName.Location = New System.Drawing.Point(215, 123)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(0, 24)
        Me.lblFirstName.TabIndex = 73
        Me.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lbl2ndDoseVaccine)
        Me.GroupBox2.Controls.Add(Me.lbl2ndDoseDate)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.lbl1stDoseVaccine)
        Me.GroupBox2.Controls.Add(Me.lbl1stDoseDate)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(802, 38)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(462, 426)
        Me.GroupBox2.TabIndex = 60
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "VACCINATION RECORDS:"
        '
        'lbl2ndDoseVaccine
        '
        Me.lbl2ndDoseVaccine.AutoSize = True
        Me.lbl2ndDoseVaccine.BackColor = System.Drawing.Color.Transparent
        Me.lbl2ndDoseVaccine.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndDoseVaccine.ForeColor = System.Drawing.Color.White
        Me.lbl2ndDoseVaccine.Location = New System.Drawing.Point(217, 377)
        Me.lbl2ndDoseVaccine.Name = "lbl2ndDoseVaccine"
        Me.lbl2ndDoseVaccine.Size = New System.Drawing.Size(0, 24)
        Me.lbl2ndDoseVaccine.TabIndex = 72
        Me.lbl2ndDoseVaccine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl2ndDoseDate
        '
        Me.lbl2ndDoseDate.AutoSize = True
        Me.lbl2ndDoseDate.BackColor = System.Drawing.Color.Transparent
        Me.lbl2ndDoseDate.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndDoseDate.ForeColor = System.Drawing.Color.White
        Me.lbl2ndDoseDate.Location = New System.Drawing.Point(217, 321)
        Me.lbl2ndDoseDate.Name = "lbl2ndDoseDate"
        Me.lbl2ndDoseDate.Size = New System.Drawing.Size(0, 24)
        Me.lbl2ndDoseDate.TabIndex = 71
        Me.lbl2ndDoseDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(46, 377)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(145, 24)
        Me.Label16.TabIndex = 70
        Me.Label16.Text = "Vaccine Used:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(130, 321)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 24)
        Me.Label17.TabIndex = 69
        Me.Label17.Text = "Date:"
        '
        'lbl1stDoseVaccine
        '
        Me.lbl1stDoseVaccine.AutoSize = True
        Me.lbl1stDoseVaccine.BackColor = System.Drawing.Color.Transparent
        Me.lbl1stDoseVaccine.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stDoseVaccine.ForeColor = System.Drawing.Color.White
        Me.lbl1stDoseVaccine.Location = New System.Drawing.Point(217, 209)
        Me.lbl1stDoseVaccine.Name = "lbl1stDoseVaccine"
        Me.lbl1stDoseVaccine.Size = New System.Drawing.Size(0, 24)
        Me.lbl1stDoseVaccine.TabIndex = 68
        Me.lbl1stDoseVaccine.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl1stDoseDate
        '
        Me.lbl1stDoseDate.AutoSize = True
        Me.lbl1stDoseDate.BackColor = System.Drawing.Color.Transparent
        Me.lbl1stDoseDate.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stDoseDate.ForeColor = System.Drawing.Color.White
        Me.lbl1stDoseDate.Location = New System.Drawing.Point(217, 153)
        Me.lbl1stDoseDate.Name = "lbl1stDoseDate"
        Me.lbl1stDoseDate.Size = New System.Drawing.Size(0, 24)
        Me.lbl1stDoseDate.TabIndex = 67
        Me.lbl1stDoseDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(234, 107)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(138, 31)
        Me.Label13.TabIndex = 66
        Me.Label13.Text = "First Dose"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Raleway", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(213, 275)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(181, 31)
        Me.Label14.TabIndex = 65
        Me.Label14.Text = "Second Dose"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(46, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(145, 24)
        Me.Label7.TabIndex = 62
        Me.Label7.Text = "Vaccine Used:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(130, 153)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 24)
        Me.Label8.TabIndex = 61
        Me.Label8.Text = "Date:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(118, 441)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(87, 24)
        Me.Label9.TabIndex = 59
        Me.Label9.Text = "Gender:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(32, 388)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(175, 24)
        Me.Label4.TabIndex = 58
        Me.Label4.Text = "Contact Number:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(111, 335)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 24)
        Me.Label5.TabIndex = 57
        Me.Label5.Text = "Address:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(71, 282)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 24)
        Me.Label6.TabIndex = 56
        Me.Label6.Text = "Date of Birth:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(86, 229)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 24)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "Last Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(63, 176)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 24)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Middle Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(86, 123)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 24)
        Me.Label1.TabIndex = 53
        Me.Label1.Text = "First Name:"
        '
        'btnBook
        '
        Me.btnBook.BackColor = System.Drawing.Color.White
        Me.btnBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBook.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBook.ForeColor = System.Drawing.Color.Black
        Me.btnBook.Location = New System.Drawing.Point(43, 588)
        Me.btnBook.Name = "btnBook"
        Me.btnBook.Size = New System.Drawing.Size(440, 65)
        Me.btnBook.TabIndex = 61
        Me.btnBook.Text = "BOOK AN APPOINTMENT"
        Me.btnBook.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Red
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogOut.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.Black
        Me.btnLogOut.Location = New System.Drawing.Point(1135, 588)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(212, 65)
        Me.btnLogOut.TabIndex = 62
        Me.btnLogOut.Text = "LOG-OUT"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'lblPlease
        '
        Me.lblPlease.AutoSize = True
        Me.lblPlease.BackColor = System.Drawing.Color.Transparent
        Me.lblPlease.Font = New System.Drawing.Font("Raleway", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlease.ForeColor = System.Drawing.Color.White
        Me.lblPlease.Location = New System.Drawing.Point(599, 615)
        Me.lblPlease.Name = "lblPlease"
        Me.lblPlease.Size = New System.Drawing.Size(419, 16)
        Me.lblPlease.TabIndex = 70
        Me.lblPlease.Text = "BSIT - 201I | Group 6 | Vaccination Registry System | ITC - C502"
        '
        'frmProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = Global.VaccineSystem_Group6.My.Resources.Resources.BG_WITH_STRIPE
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1390, 700)
        Me.Controls.Add(Me.lblPlease)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnBook)
        Me.Controls.Add(Me.grpProfile)
        Me.Controls.Add(Me.lblGRP6)
        Me.Controls.Add(Me.lblDateTime)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmProfile"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "G6 | Vaccination System | Profile Page"
        Me.grpProfile.ResumeLayout(False)
        Me.grpProfile.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tmrProfile As Timer
    Friend WithEvents lblDateTime As Label
    Friend WithEvents lblGRP6 As Label
    Friend WithEvents grpProfile As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lbl2ndDoseVaccine As Label
    Friend WithEvents lbl2ndDoseDate As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents lbl1stDoseVaccine As Label
    Friend WithEvents lbl1stDoseDate As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnBook As Button
    Friend WithEvents btnLogOut As Button
    Friend WithEvents lblGender As Label
    Friend WithEvents lblContactNumber As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblDateOfBirth As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblMiddleName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblAccountId As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents lblPlease As Label
End Class
