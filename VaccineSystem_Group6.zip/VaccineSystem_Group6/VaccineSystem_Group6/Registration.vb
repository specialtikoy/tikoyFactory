﻿Imports System.Data
Imports System.Data.SqlClient

Public Class frmRegister

    Dim userNameTester, gender, passWord As String

    Dim accountId As Integer

    Private Sub tmrRegister_Tick(ByVal sender As Object, e As EventArgs) Handles tmrRegister.Tick

        passWord = txtPassword.Text

        lblDateTime.Text = DateTime.Now
        dtpDateOfBirth.MaxDate = DateTime.Today

        If (txtFirstName.Text <> "" And txtLastName.Text <> "" And txtContactNumber.Text <> "" And
            txtAddress.Text <> "" And dtpDateOfBirth.Value <> DateTime.Today And txtUsername.Text <> "") And (passWord.Length >= 10 And (
            passWord.Contains("1") Or passWord.Contains("2") Or passWord.Contains("3") Or passWord.Contains("4") Or passWord.Contains("5") Or
            passWord.Contains("6") Or passWord.Contains("7") Or passWord.Contains("8") Or passWord.Contains("9") Or passWord.Contains("0")) And (
            passWord.Contains("~") Or passWord.Contains("`") Or passWord.Contains("!") Or passWord.Contains("@") Or passWord.Contains("#") Or
            passWord.Contains("$") Or passWord.Contains("%") Or passWord.Contains("^") Or passWord.Contains("&") Or passWord.Contains("*") Or
            passWord.Contains("(") Or passWord.Contains(")") Or passWord.Contains("-") Or passWord.Contains("_") Or passWord.Contains("+") Or
            passWord.Contains("=") Or passWord.Contains("{") Or passWord.Contains("}") Or passWord.Contains("[") Or passWord.Contains("]") Or
            passWord.Contains("|") Or passWord.Contains("\") Or passWord.Contains(";") Or passWord.Contains(":") Or passWord.Contains("<") Or
            passWord.Contains(">") Or passWord.Contains(",") Or passWord.Contains(".") Or passWord.Contains("/") Or passWord.Contains("?"))) Then
            txtValid.BackColor = Color.Lime
            btnCreate.Enabled = True
        Else
            txtValid.BackColor = Color.Red
            btnCreate.Enabled = False
        End If

    End Sub

    Private Sub chkMale_CheckedChanged(sender As Object, e As EventArgs) Handles chkMale.CheckedChanged

        If chkMale.Checked = True Then
            chkFemale.CheckState = False
            gender = "Male"
        End If

    End Sub

    Private Sub chkFemale_CheckedChanged(sender As Object, e As EventArgs) Handles chkFemale.CheckedChanged

        If chkFemale.Checked = True Then
            chkMale.CheckState = False
            gender = "Female"
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Dim Homepage As frmHomepage
        Homepage = New frmHomepage

        txtFirstName.Clear()
        txtMiddleName.Clear()
        txtLastName.Clear()
        txtContactNumber.Clear()
        txtAddress.Clear()
        dtpDateOfBirth.ResetText()
        chkMale.CheckState = False
        chkFemale.CheckState = False
        txtUsername.Clear()
        txtPassword.Clear()

        Me.Hide()
        Homepage.Show()
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
        Dim searchUsername As SqlCommand = New SqlCommand("SELECT [Username] FROM [dbo].[user_tbl] WHERE [Username] COLLATE SQL_Latin1_General_CP1_CS_AS = '" + txtUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS ", connection)


        connection.Open()

        userNameTester = searchUsername.ExecuteScalar

        searchUsername.ExecuteNonQuery()
        connection.Close()

        If txtUsername.Text = userNameTester Then
            MessageBox.Show("Username is already taken", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            Dim question As DialogResult = MessageBox.Show("Are all fields filled-up correctly?", "VACCINATION SYSTEM", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            If question = DialogResult.Yes Then

                Dim connection2 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
                Dim insertIntoTableCmd As SqlCommand = New SqlCommand("INSERT INTO [dbo].[user_tbl] ([First_Name],[Middle_Name],[Last_Name],[Username],[Password],[Date_Of_Birth],[Address],[Contact_Number],[Gender]) 
             VALUES('" + txtFirstName.Text + "','" + txtMiddleName.Text + "','" + txtLastName.Text + "','" + txtUsername.Text + "','" + txtPassword.Text + "','" + dtpDateOfBirth.Value.ToShortDateString + "','" + txtAddress.Text + "','" + txtContactNumber.Text + "','" + gender + "')", connection2)

                connection2.Open()
                insertIntoTableCmd.ExecuteNonQuery()
                connection2.Close()

                Dim confirmation As DialogResult = MessageBox.Show("Registration successful. Please generate ACCOUNT ID to proceed to next step.", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Information)
                If confirmation = DialogResult.OK Then
                    btnGenerate.Enabled = True
                    btnGenerate.BackColor = Color.Lime
                Else
                    btnGenerate.Enabled = False
                End If

            ElseIf question = DialogResult.No Then
                MessageBox.Show("Please check all fields thoroughly.", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        End If

    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click

        Dim question2 As DialogResult = MessageBox.Show("REMINDER: Please write down your ACCOUNT ID before proceeding to next step", "VACCINATION SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Information)
        If question2 = DialogResult.OK Then
            Dim connection3 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
            Dim getAccountIdCmd As SqlCommand = New SqlCommand("SELECT [Account_Id] FROM [dbo].[user_tbl] WHERE [Username] = '" + txtUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS ", connection3)

            connection3.Open()

            accountId = getAccountIdCmd.ExecuteScalar
            txtAccountId.Text = accountId

            connection3.Close()

            Dim question3 As DialogResult = MessageBox.Show("Do you have your ACCOUNT ID?", "VACCINATION SYSTEM", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            If question3 = DialogResult.Yes Then
                Dim Appointment As frmAppointment
                Appointment = New frmAppointment
                Me.Hide()
                Appointment.Show()
            End If

            btnGenerate.BackColor = Color.White

        End If

    End Sub


End Class