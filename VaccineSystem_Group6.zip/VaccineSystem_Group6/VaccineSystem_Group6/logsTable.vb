﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmLogsTable

    Private Sub frmLogsTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowLogsTable()

    End Sub

    Private Sub ShowLogsTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[logs_tbl] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvLogsTable.DataSource = table

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

End Class