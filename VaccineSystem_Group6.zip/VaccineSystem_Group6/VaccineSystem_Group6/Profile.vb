﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmProfile

    Public Property userNameString As String
    Public Property passWordString As String
    Public Property timeIn As String
    Public Property purpose As String

    Dim secondDoseDateHolder, secondDoseVaccineHolder As Object

    Dim nullValue As DBNull


    Private Sub frmProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        showDataOne()
        ShowDataTwo()

    End Sub

    Public Sub showDataOne()

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Using getAccountId As SqlCommand = New SqlCommand("SELECT [Account_Id] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
            Using getFirstName As SqlCommand = New SqlCommand("SELECT [First_Name] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                Using getMiddleName As SqlCommand = New SqlCommand("SELECT [Middle_Name] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                    Using getLastName As SqlCommand = New SqlCommand("SELECT [Last_Name] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                        Using getBirthday As SqlCommand = New SqlCommand("SELECT [Date_Of_Birth] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                            Using getAddress As SqlCommand = New SqlCommand("SELECT [Address] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                                Using getContactNumber As SqlCommand = New SqlCommand("SELECT [Contact_Number] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                                    Using getGender As SqlCommand = New SqlCommand("SELECT [Gender] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                                        Using get1stDoseDate As SqlCommand = New SqlCommand("SELECT [First_Dose] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
                                            Using get2ndDoseDate As SqlCommand = New SqlCommand("SELECT [Second_Dose] FROM [dbo].[user_tbl] WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Password] = '" + passWordString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)

                                                connection.Open()

                                                Try
                                                    grpProfile.Text = userNameString
                                                    lblAccountId.Text = getAccountId.ExecuteScalar()
                                                    lblFirstName.Text = getFirstName.ExecuteScalar()
                                                    lblMiddleName.Text = getMiddleName.ExecuteScalar()
                                                    lblLastName.Text = getLastName.ExecuteScalar()
                                                    lblDateOfBirth.Text = getBirthday.ExecuteScalar()
                                                    lblAddress.Text = getAddress.ExecuteScalar()
                                                    lblContactNumber.Text = getContactNumber.ExecuteScalar()
                                                    lblGender.Text = getGender.ExecuteScalar()
                                                    lbl1stDoseDate.Text = get1stDoseDate.ExecuteScalar()
                                                    secondDoseDateHolder = get2ndDoseDate.ExecuteScalar()

                                                    If secondDoseDateHolder.GetType.Equals(nullValue) Then
                                                        lbl2ndDoseDate.Text = ""
                                                    Else
                                                        lbl2ndDoseDate.Text = secondDoseDateHolder.ToString
                                                    End If

                                                Catch ex As Exception
                                                    MsgBox(ex.ToString())
                                                End Try

                                                connection.Close()

                                            End Using
                                        End Using
                                    End Using
                                End Using
                            End Using
                        End Using
                    End Using
                End Using
            End Using
        End Using

    End Sub

    Public Sub ShowDataTwo()

        Dim connection As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")

        Using get1stDoseVaccine As SqlCommand = New SqlCommand("SELECT [Vaccine_Brand] FROM [dbo].[appointments_tbl] WHERE [Account_Id] = '" + lblAccountId.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Date] = '" + lbl1stDoseDate.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)
            Using get2ndDoseVaccine As SqlCommand = New SqlCommand("SELECT [Vaccine_Brand] FROM [dbo].[appointments_tbl] WHERE [Account_Id] = '" + lblAccountId.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [Date] = '" + lbl2ndDoseDate.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", connection)

                connection.Open()

                Try

                    lbl1stDoseVaccine.Text = get1stDoseVaccine.ExecuteScalar()
                    secondDoseVaccineHolder = get2ndDoseVaccine.ExecuteScalar()

                    If secondDoseVaccineHolder Is Nothing Then
                        lbl2ndDoseVaccine.Text = ""
                    Else
                        lbl2ndDoseVaccine.Text = secondDoseVaccineHolder.ToString
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString())
                End Try

                connection.Close()

            End Using
        End Using

    End Sub


    Private Sub tmrProfile_Tick(sender As Object, e As EventArgs) Handles tmrProfile.Tick

        lblDateTime.Text = DateTime.Now

        If lbl2ndDoseDate.Text <> "" Then
            btnBook.Enabled = False
        End If

    End Sub

    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click

        Dim Appointment As frmAppointment
        Appointment = New frmAppointment

        Dim question3 As DialogResult = MessageBox.Show("Do you have your ACCOUNT ID?", "VACCINATION SYSTEM", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question3 = DialogResult.Yes Then

            purpose = "Book 2nd Dose"

            Dim connection3 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
            Dim updateTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[logs_tbl] SET [Purpose] = '" + purpose + "',  [DateTimeOut] = '" + DateTime.Now.AddSeconds(19).ToString + "' WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [DateTimeIn] = '" + timeIn + "'", connection3)

            connection3.Open()
            updateTimeOutLog.ExecuteNonQuery()
            connection3.Close()

            Me.Hide()
            Appointment.Show()
        End If

    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click

        purpose = "View Profile"

        Dim question As DialogResult = MessageBox.Show("Are you sure you want to log-out?", "VACCINATION SYSTEM", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim connection2 As SqlConnection = New SqlConnection("Data Source=ROG;Initial Catalog=GRP6DB;Integrated Security=True")
            Dim updateTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[logs_tbl] SET [Purpose] = '" + purpose + "',  [DateTimeOut] = '" + DateTime.Now.ToString + "' WHERE [Username] = '" + userNameString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [DateTimeIn] = '" + timeIn + "'", connection2)

            connection2.Open()
            updateTimeOutLog.ExecuteNonQuery()
            connection2.Close()

            Dim Homepage As frmHomepage
            Homepage = New frmHomepage

            Me.Hide()
            Homepage.Show()

        End If

    End Sub


End Class