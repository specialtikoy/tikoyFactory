﻿Public Class frmHomepage

    Private Sub tmrHome_Tick(ByVal sender As Object, e As EventArgs) Handles tmrHome.Tick

        lblDateTime.Text = DateTime.Now

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Application.Exit()

    End Sub

    Private Sub btnHomeLogin_Click(sender As Object, e As EventArgs) Handles btnHomeLogin.Click

        Dim Login As frmLogin
        Login = New frmLogin

        Me.Hide()
        Login.Show()

    End Sub

    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click

        Dim Registration As frmRegister
        Registration = New frmRegister

        Me.Hide()
        Registration.Show()

    End Sub

End Class
