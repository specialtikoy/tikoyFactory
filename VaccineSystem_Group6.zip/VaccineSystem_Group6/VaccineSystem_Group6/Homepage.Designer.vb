﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHomepage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmHomepage))
        Me.btnSignUp = New System.Windows.Forms.Button()
        Me.btnHomeLogin = New System.Windows.Forms.Button()
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.tmrHome = New System.Windows.Forms.Timer(Me.components)
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pbxLogo = New System.Windows.Forms.PictureBox()
        Me.lblGRP6 = New System.Windows.Forms.Label()
        Me.lblPlease = New System.Windows.Forms.Label()
        CType(Me.pbxLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSignUp
        '
        Me.btnSignUp.BackColor = System.Drawing.Color.White
        Me.btnSignUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSignUp.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignUp.ForeColor = System.Drawing.Color.Black
        Me.btnSignUp.Location = New System.Drawing.Point(522, 275)
        Me.btnSignUp.Name = "btnSignUp"
        Me.btnSignUp.Size = New System.Drawing.Size(337, 65)
        Me.btnSignUp.TabIndex = 0
        Me.btnSignUp.Text = "SIGN UP FOR 1st DOSE"
        Me.btnSignUp.UseVisualStyleBackColor = False
        '
        'btnHomeLogin
        '
        Me.btnHomeLogin.BackColor = System.Drawing.Color.White
        Me.btnHomeLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHomeLogin.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHomeLogin.ForeColor = System.Drawing.Color.Black
        Me.btnHomeLogin.Location = New System.Drawing.Point(522, 162)
        Me.btnHomeLogin.Name = "btnHomeLogin"
        Me.btnHomeLogin.Size = New System.Drawing.Size(337, 65)
        Me.btnHomeLogin.TabIndex = 0
        Me.btnHomeLogin.Text = "LOG-IN"
        Me.btnHomeLogin.UseVisualStyleBackColor = False
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTime.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.White
        Me.lblDateTime.Location = New System.Drawing.Point(790, 9)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(148, 18)
        Me.lblDateTime.TabIndex = 0
        Me.lblDateTime.Text = "                                   "
        '
        'tmrHome
        '
        Me.tmrHome.Enabled = True
        Me.tmrHome.Interval = 1000
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Red
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Black
        Me.btnClose.Location = New System.Drawing.Point(591, 391)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(200, 65)
        Me.btnClose.TabIndex = 0
        Me.btnClose.Text = "CLOSE"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'pbxLogo
        '
        Me.pbxLogo.BackColor = System.Drawing.Color.Transparent
        Me.pbxLogo.BackgroundImage = CType(resources.GetObject("pbxLogo.BackgroundImage"), System.Drawing.Image)
        Me.pbxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbxLogo.Location = New System.Drawing.Point(89, 106)
        Me.pbxLogo.Name = "pbxLogo"
        Me.pbxLogo.Size = New System.Drawing.Size(350, 350)
        Me.pbxLogo.TabIndex = 4
        Me.pbxLogo.TabStop = False
        '
        'lblGRP6
        '
        Me.lblGRP6.AutoSize = True
        Me.lblGRP6.BackColor = System.Drawing.Color.Transparent
        Me.lblGRP6.Font = New System.Drawing.Font("Raleway", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGRP6.ForeColor = System.Drawing.Color.White
        Me.lblGRP6.Location = New System.Drawing.Point(12, 9)
        Me.lblGRP6.Name = "lblGRP6"
        Me.lblGRP6.Size = New System.Drawing.Size(279, 24)
        Me.lblGRP6.TabIndex = 6
        Me.lblGRP6.Text = "Group 6 : Vaccination System"
        '
        'lblPlease
        '
        Me.lblPlease.AutoSize = True
        Me.lblPlease.BackColor = System.Drawing.Color.Transparent
        Me.lblPlease.Font = New System.Drawing.Font("Raleway", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlease.ForeColor = System.Drawing.Color.White
        Me.lblPlease.Location = New System.Drawing.Point(259, 504)
        Me.lblPlease.Name = "lblPlease"
        Me.lblPlease.Size = New System.Drawing.Size(419, 16)
        Me.lblPlease.TabIndex = 71
        Me.lblPlease.Text = "BSIT - 201I | Group 6 | Vaccination Registry System | ITC - C502"
        '
        'frmHomepage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.VaccineSystem_Group6.My.Resources.Resources.BG
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(950, 550)
        Me.Controls.Add(Me.lblPlease)
        Me.Controls.Add(Me.lblGRP6)
        Me.Controls.Add(Me.pbxLogo)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblDateTime)
        Me.Controls.Add(Me.btnHomeLogin)
        Me.Controls.Add(Me.btnSignUp)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.Name = "frmHomepage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "G6 | Vaccination System | Homepage"
        CType(Me.pbxLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSignUp As Button
    Friend WithEvents btnHomeLogin As Button
    Friend WithEvents lblDateTime As Label
    Friend WithEvents tmrHome As Timer
    Friend WithEvents btnClose As Button
    Friend WithEvents pbxLogo As PictureBox
    Friend WithEvents lblGRP6 As Label
    Friend WithEvents lblPlease As Label
End Class
